# payin7-php

PHP bindings for the Payin7 Service (http://www.payin7.com)

If you need any help with the integration you may contact us at:

- Payin7 official webpage: http://www.payin7.com
- Technical Support: technical@payin7.com

You can also find us at:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (and all related code): https://github.com/payin7-payments

------------------------------------------------------------------------

Si necesitas ayuda con la integración puedes ponerte en contacto con nosotros en:

- Página Webl: http://www.payin7.com
- Soporte Técnico: technical@payin7.com
- Teléfono:  91 164 9994

También nos puedes encontrar en:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (y todo el código relacionado): https://github.com/payin7-payments