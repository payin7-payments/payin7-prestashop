# payin7-php

Payin7 Prestashop Module (http://www.payin7.com)

The module has been tested and is compatible with:

- Prestashop 1.4
- Prestashop 1.5
- Prestashop 1.6

If you need any help with the integration you may contact us at:

- Payin7 official webpage: http://www.payin7.com
- Technical Support: technical@payin7.com

You can also find us at:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (and all related code): https://github.com/payin7-payments

------------------------------------------------------------------------

Payin7 Prestashop Módulo (http://www.payin7.com)

El plugin ha sido probado y es compatible con:

- Prestashop 1.4
- Prestashop 1.5
- Prestashop 1.6

Si necesitas ayuda con la integración puedes ponerte en contacto con nosotros en:

- Página Webl: http://www.payin7.com
- Soporte Técnico: technical@payin7.com
- Teléfono:  91 164 9994

También nos puedes encontrar en:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (y todo el código relacionado): https://github.com/payin7-payments