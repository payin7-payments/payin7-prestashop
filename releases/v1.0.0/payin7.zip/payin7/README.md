Payin7 Prestashop Module (http://www.payin7.com)

The module has been tested and is compatible with:

- Prestashop 1.4
- Prestashop 1.5
- Prestashop 1.6

If you need any help with the integration you may contact us at:

- Payin7 official webpage: http://www.payin7.com
- Technical Support: technical@payin7.com

You can also find us at:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (and all related code): https://github.com/payin7-payments

------------------------------------------------------------------------

Payin7 Prestashop Módulo (http://www.payin7.com)

El plugin ha sido probado y es compatible con:

- Prestashop 1.4
- Prestashop 1.5
- Prestashop 1.6

Si necesitas ayuda con la integración puedes ponerte en contacto con nosotros en:

- Página Webl: http://www.payin7.com
- Soporte Técnico: technical@payin7.com
- Teléfono:  91 164 9994

También nos puedes encontrar en:

- Facebook: https://www.facebook.com/payinseven/
- Twitter: https://twitter.com/payin7
- GitHub (y todo el código relacionado): https://github.com/payin7-payments

------------------------------------------------------------------------

PAYIN7 offers the clients the opportunity of choosing between two forms of payment:

- PAYMENT IN 7 DAYS allows clients to pay after they have received their products. 
- FINANCE PAYMENT clients can pay for their products with downpayments - from 2 to 6 installments.

NO NEED TO USE  A CREDIT CARD - The clients can choose not to use their credit card which gives a greater confidence in payment.
ACCESS TO EXPENSIVE PRODUCTS - Clients may purchase products which otherwise they could not afford. Wide range of products at their choice.
GIFTS TO YOUR CLIENTS FOR FINANCING – Using gamification and other promotions and offer them to the clients who use our products.
QUICK AND EASY INTEGRATION – Starting up with our platform is fast – only a few minutes are necessary.
COMPATIBLE WITH OTHER PAYMENT METHODS – You can keep using paypal, credit card or any other payment system.
SALES PROMOTIONS - Use the possibility of financing as a marketing tool.
DIFFERENTIATE FROM YOUR COMPETITORS – Always be one step ahead of your competitors.
ACCESS TO NEW CLIENTS - A wider range of customers will pay for more expensive products.

PAYIN7 ofrece a sus clientes la financiación de sus ventas a través de dos productos de pago:

- Con PAGO EN 7 DIAS el cliente podrá pagar una vez recibida la mercancía. 
- Con PAGO FINANCIADO el cliente final divide sus pagos entre 2 y 6 cuotas.

SIN NECESIDAD DE USAR UNA TARJETA DE CREDITO – El cliente final puede optar a usar o no su tarjeta de crédito en sus compras.  Dándole mayor confianza en el pago.
ACESSO A PRODUCTOS ANTES NO ASUMIBLES – Tu cliente podrá adquirir productos que de otra manera no podrían asumir.  Amplia la gama de productos a su alcance.
REGALOS PARA TUS CLIENTES POR FINANCIARSE – Realizamos sorteos entre tus clientes lo cual aumentará tus ventas. 
INTEGRACION SENCILLA Y RAPIDA – En pocos minutos podrás empezar a operar con nosotros. 
COMPATIBLE CON OTROS METODOS DE PAGO – Compatible con paypal, VISA o cualquier otro sistema de pago. 
PROMOCIONES QUE BENEFICIAN LAS VENTAS DE LOS ECOMMERCE – Usa la posibilidad de financiar como herramienta de marketing. 
DIFERENCIACION CON LA COMPETENCIA – Ve un paso por delante de tus competidores. 
ACESSO A NUEVOS CLIENTES – La posibilidad de financiar abre tu ecommerce a nuevos clientes. Un mayor rango de clientes van a pagar por tus productos más costosos.
